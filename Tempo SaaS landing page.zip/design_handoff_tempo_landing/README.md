# Handoff: Tempo marketing landing page

## Overview
This is a single-page marketing site for **Tempo**, an AI labour platform for warehousing and 3PL. It has two jobs:
1. **Customer acquisition.** The main conversion is **Start free trial** (14 days, no card needed). The secondary conversion is **Talk to sales**.
2. **SEO.** The target terms are *AI rostering*, *labour optimisation*, *warehouse workforce management*, *3PL labour cost* and *UKG / Deputy alternative*.

Audiences: 3PL operations directors, warehouse GMs and site managers, CFOs and finance teams, workforce planning leads, and existing UKG/Kronos or Deputy customers. The positioning is that Tempo is a **complete standalone labour platform** that can also integrate with UKG and Deputy.

## About the design files
The files in `reference/` are **design references built in HTML**. They're prototypes that show the intended look and behaviour; they're not production code. Rebuild the page in the target stack.

**Recommended stack (no codebase exists yet):** Next.js (App Router) or Astro, using static generation for SEO, with Tailwind or CSS Modules. Ship close to zero client JS: the FAQ accordion and the billing toggle are the only interactive parts. Host on Vercel or Netlify with a CDN.

To view the reference, open `reference/Tempo Landing Page.dc.html` in a browser. `support.js` must sit next to it. Everything is styled inline. The copy and data arrays live in the `renderVals()` method of the `<script>` block at the bottom of the file, and the same content is also extracted into `content.json`.

## Fidelity
**High fidelity.** The colours, type, spacing, radii and copy are final. Match them exactly.

Figures marked *illustrative* (the stats band, the A$ prices and the product mock numbers) are **placeholders**. Marketing must confirm them before launch, and they should stay editable in the CMS.

## Page structure (top → bottom)
Container: `max-width:1240px; margin:0 auto; padding:0 28px`. Most sections use `padding:120px 28px 40px` (some use 100px top). Two-column sections use `grid-template-columns: repeat(auto-fit, minmax(min(100%, 380–480px), 1fr)); gap:56–64px`, so they stack to one column when the viewport is narrow.

1. **Sticky header**
   - Background `rgba(246,246,243,.86)` with `backdrop-filter: blur(12px)`, and a 1px `#e4e4df` bottom border. Padding 14×28.
   - Contents: logo mark + "Tempo" wordmark (800 weight, 21px, −0.03em tracking); nav links (14.5px, 500 weight, `#4c555f`) to `#how`, `#engine`, `#integrations`, `#pricing` and `#resources`; "Sign in"; a dark pill CTA reading "Start free trial".
2. **Hero** (2 columns)
   - Eyebrow chip in mono uppercase 12px: "AI labour platform for warehousing & 3PL".
   - **H1:** "Every shift, perfectly in tempo." (`clamp(44px,6.2vw,80px)`, 800 weight, line-height .98, −0.045em).
   - Sub-copy (18–21px, `#4c555f`).
   - Two CTAs: a primary dark pill and a secondary white pill with a border.
   - Trust row: "14-day trial · No credit card · Live on your first site in a week".
   - Right column: a product card (white, radius 20, shadow `0 30px 60px -30px rgba(27,34,40,.25)`). It contains a 7-day × 3-shift coverage heatmap (cells 30px tall, radius 6, green/amber/red), a legend, a 3-cell cost strip (baseline A$184,200 / proposed A$163,900 / delta −11.0% in green), and a confidence line with an "Approve & publish" pill.
3. **Stats band**
   - White, with borders top and bottom. Four stats, each 36–52px at 800 weight.
   - Disclaimer underneath in 11px mono `#7a828b`.
4. **How it works** (`#how`)
   - H2 plus intro, then an `<ol>` of 4 cards (white, 1px `#e4e4df` border, radius 18, padding 28, min-height 240).
   - Each card has a step number, a coloured square (green, green, amber, red), an H3 (24px) and body text.
5. **AI engine** (`#engine`)
   - Left column is sticky (`top:110px`): H2, copy and a text link with a 2px green underline.
   - Right column: 10 model tiles on a 1px hairline grid (gap 1px on `#e4e4df`). Each tile has a number, a method tag in mono (FORECAST, MILP, CP-SAT…), an H3 (18px) and a description.
6. **Explainability panel**
   - Dark card `#1b2228`, radius 28, padding `clamp(32px,5vw,72px)`.
   - Left column: H2 "See exactly why. Approve it. Done." and 3 bullets with coloured squares.
   - Right column: an inner card `#242c33` with a `#344049` border, showing "Primary drivers", "Missing evidence" (dashed border) and the status pills validated → approved → confirmed.
7. **Kiosk & attendance**
   - Kiosk mock: PIN dots, a 3×4 keypad (64px columns, 56px keys, radius 14, `#f2f2ee`) and a green confirmation bar `#eef8f2` / `#126b3c`.
   - Copy column with 3 mini features.
8. **Integrations** (`#integrations`)
   - H2 with copy alongside it, then 6 tiles (white, radius 16, padding 22).
9. **Security**
   - H2 on the left. On the right, 4 items in a 2×2 grid, each with a 1px `#d6d6d0` top rule.
10. **Pricing** (`#pricing`)
    - Centred H2 above a segmented Monthly / Annual toggle (track `#ebebe6`; the active segment is white).
    - 3 plan cards with `minmax(min(100%,250px),1fr)`. **Growth** is the inverted card (`#1b2228` background, green CTA, "Most popular" badge).
    - Annual prices are shown by default.
11. **FAQ**
    - H2 on the left and the accordion on the right. Rows have a 1px `#d6d6d0` divider, the question is an H3 at 18px/600, and the toggle icon is +/–. The first item is open by default.
12. **Resources** (`#resources`)
    - 3 article cards. Each has a 16:10 image (currently a striped placeholder that needs real covers), a mono tag and an H3 (21px).
13. **Final CTA**
    - White card, radius 28. Large logo mark (14px cells), H2 "Get every site to green." and two CTAs.
14. **Footer**
    - Brand column plus 4 link columns (`minmax(130px,1fr)`).
    - Legal row: "© 2026 Tempo by Ensemble Solutions. Made in Melbourne." with Privacy / Terms / Security links.

## Interactions & behaviour
- Anchor nav with `scroll-behavior: smooth`. Offset anchors by the sticky header height (about 64px) with `scroll-margin-top`.
- **Buttons** (dark pill): hover changes the background to `#0b8f50`. Secondary pills: hover changes the border to `#1b2228`. Text links: hover changes the colour to `#0b8f50`. Use about 150ms ease transitions.
- **Billing toggle:** `billing: 'annual' | 'monthly'`, defaulting to annual.
  - Starter: A$9 monthly, A$7 annual. Growth: A$15 monthly, A$12 annual. Enterprise: "Custom".
  - Use `role="group"` and `aria-pressed` on the segments.
- **FAQ accordion:** one item open at a time (`openIndex`, default 0). Clicking the open item closes it.
  - Implement with `<button aria-expanded aria-controls>`, or with native `<details>`/`<summary>`.
  - **Answers must be in the server-rendered HTML** (hidden, not omitted) so they can be indexed.
- Responsive: every grid uses `auto-fit`, and type scales with `clamp()`. Below about 760px, collapse the header nav into a menu button. The prototype only wraps the nav, so the mobile menu still needs designing to match.
- Nothing on the page animates. You can add optional fade-ups on scroll (opacity 0→1, translateY 12px→0, 400ms) if you respect `prefers-reduced-motion`.

## State
- `billing` (client)
- `faqOpenIndex` (client)

No data fetching. All content is static and should be CMS-driven (see `content.json`).

## Design tokens
See `tokens.css`.

**Colours**

| Token | Value |
|---|---|
| ink | `#1b2228` |
| ink-2 | `#242c33` |
| ink-line | `#344049` |
| body | `#4c555f` |
| muted | `#5a636d` |
| subtle | `#7a828b` |
| bg | `#f6f6f3` |
| surface | `#ffffff` |
| surface-2 | `#fafaf8` |
| key | `#f2f2ee` |
| track | `#ebebe6` |
| line | `#e4e4df` |
| line-strong | `#d6d6d0` |
| green (brand) | `#0b9b57` |
| green-hover / text | `#0b8f50` |
| green-on-dark | `#5fd59a` |
| amber | `#f5a833` |
| red | `#e43a2e` |

Status pills:
- completed / confirmed: `#dafbe1` / `#1a7f37`
- validated: `#fff8c5` / `#9a6700`

**Type**
- Plus Jakarta Sans at 400, 500, 600, 700 and 800.
- JetBrains Mono at 400 and 500, for eyebrows, tags and data labels.
- Headings use tight negative tracking (−0.02 to −0.045em).
- Scale:

| Element | Size |
|---|---|
| H1 | clamp(44, 6.2vw, 80) |
| H2 | clamp(34, 4.4vw, 56) |
| H3 | 18–24 |
| Lead | 18 |
| Body | 15–16 |
| Small | 13–14.5 |
| Eyebrow | 12 mono, 0.08em, uppercase, green |

**Radius:** pill 999 · cards 16 / 18 / 20 / 22 · feature panels 28 · cells 6 · logo cells 2 (4 at large size)

**Shadow:** hero card only: `0 1px 0 #e4e4df, 0 30px 60px -30px rgba(27,34,40,.25)`

**Spacing:** 4-based. Common values are 6, 8, 10, 12, 14, 18, 22, 26, 28, 32, 40, 44, 56, 64, 88, 100 and 120.

## Logo
The mark is a 3×3 grid of rounded squares:
- Row 1: green, green, green
- Row 2: ink, amber, ink
- Row 3: ink, red, ink

Cells are 7px with a 2px gap in the nav and footer, and 14px with a 4px gap in the CTA. Build it as inline SVG; `assets/tempo-logo.svg` is a vector version. The original raster is `assets/tempo-logo.png`.

## SEO requirements (critical)
- Static HTML with all copy server-rendered, and a single H1. The heading hierarchy is already correct in the reference: one H1, an H2 for each section, H3s for cards.
- **Meta tags.** Use the `<title>` and description in `seo/head.html`. Also add a canonical URL, Open Graph and Twitter tags, and a 1200×630 OG image (still to be designed).
- **JSON-LD** (`seo/structured-data.json`): SoftwareApplication, Organization, **FAQPage** (it must match the visible FAQ text exactly) and the Offer for each plan.
- `robots.txt` and `sitemap.xml` are in `seo/`. Replace `https://tempo.example.com` with the production domain.
- **Performance.** Target Core Web Vitals of LCP < 2.0s, CLS < 0.05 and INP < 200ms.
  - Self-host the fonts (subset to Latin, `font-display: swap`) and preload the 800 weight.
  - The hero mock is HTML/CSS rather than an image, which keeps LCP fast.
  - Article covers: AVIF/WebP, `loading="lazy"`, with explicit width and height.
- **Accessibility.**
  - Every nav uses `<nav aria-label>`, and the heatmap cells carry `title` labels. Add visually hidden text for screen readers too.
  - Make focus rings visible: `outline: 2px solid #0b9b57; outline-offset: 2px`.
  - Body text on `#f6f6f3` meets 4.5:1.
- **Analytics.** Track `cta_click` with `{location: nav|hero|engine|pricing_<plan>|final, label}`, plus `billing_toggle` and `faq_open` with `{index}`. Wire trial CTAs to `/signup?plan=<plan>&billing=<billing>` with UTMs passed through.
- **Future SEO pages.** The footer links to Solutions pages (3PL, Warehousing, UKG & Kronos users, Deputy users). Build those as separate landing pages that reuse these sections.

## Before launch
- [ ] Confirm or replace the illustrative stats, prices and mock figures.
- [ ] Article cover images and real article URLs.
- [ ] OG image and favicon set (16, 32, 180 and 512 sizes, generated from the logo SVG).
- [ ] Destinations for the signup, sign-in and sales-contact links.
- [ ] Legal pages (Privacy, Terms, Security).
- [ ] Mobile nav menu.
- [ ] Production domain in the canonical URL, sitemap and JSON-LD.

## Files
- `reference/Tempo Landing Page.dc.html` and `reference/support.js`: the visual reference you can open in a browser.
- `reference/Tempo Landing Wireframe.dc.html`: an annotated structural wireframe. It shows desktop at 1440 and mobile at 375, with the grid tracks, block heights, breakpoints and mobile reordering. Pricing shows Growth first on mobile.
- `screenshots/`: section-by-section captures at a viewport of about 910px.
  - `00-wireframe-overview`
  - `01-header-hero`
  - `02-stats`
  - `03-how-it-works`
  - `04-ai-engine`
  - `05-explainability`
  - `06-kiosk`
  - `07-integrations`
  - `08-security`
  - `09-pricing-annual`
  - `10-pricing-monthly`
  - `11-faq`
  - `12-resources`
  - `13-final-cta`
  - `14-footer`
- `content.json`: all copy and data arrays.
- `tokens.css`: design tokens as CSS custom properties.
- `seo/head.html`, `seo/structured-data.json`, `seo/robots.txt`, `seo/sitemap.xml`
- `assets/tempo-logo.svg` and `assets/tempo-logo.png`
- `CLAUDE_CODE_PROMPT.md`: a kickoff prompt to paste into Claude Code.
