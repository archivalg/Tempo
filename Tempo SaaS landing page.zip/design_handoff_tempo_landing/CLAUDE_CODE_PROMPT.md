Read `README.md` in this folder first. It is the source of truth.

Build the Tempo marketing landing page as a statically generated site, pixel-matched to `reference/Tempo Landing Page.dc.html`. Open that file in a browser to compare as you go.

- Stack: Next.js App Router (static export) + TypeScript + CSS Modules, or Tailwind configured with the values from `tokens.css`. If an existing repo is present, use its conventions instead.
- Load all copy from `content.json`. Create one component per section, in the order listed in the README.
- Self-host Plus Jakarta Sans and JetBrains Mono.
- Put the `seo/head.html` tags in metadata and inline `seo/structured-data.json` as JSON-LD. Copy `robots.txt` and `sitemap.xml` to `/public`.
- Interactive parts are only the billing toggle and the FAQ accordion. FAQ answers must be present in the static HTML.
- Add the analytics events and CTA URL scheme described in the README.
- Build a mobile nav menu for screens under 760px.
- Done when Lighthouse scores are 95 or higher for Performance, Accessibility, Best Practices and SEO on mobile, the page has no layout shift, and it renders correctly at 375, 768, 1024 and 1440px.
