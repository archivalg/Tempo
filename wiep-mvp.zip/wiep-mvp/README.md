# WIEP MVP Scaffold

A runnable MVP scaffold for the Workforce Intelligence & Execution Platform for warehousing.

## What is included

- Next.js + React app shell
- Dashboard, planning, roster, recommendations pages
- TypeScript API routes for:
  - event ingestion
  - demand forecasting
  - labour requirements
  - workforce mix optimisation
  - named roster optimisation
  - recommendations
- Shared Zod contracts package
- Python optimisation-worker placeholder
- Oracle Cloud implementation mapping docs

## What this MVP proves

The thin end-to-end loop:

```text
forecast -> labour requirements -> workforce mix -> roster -> recommendations
```

This is deliberately not the final solver engine. The TypeScript routes use MVP heuristics so the product can be validated quickly. Replace these with Python OR-Tools workers once real customer data is available.

## Run locally

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Suggested next engineering steps

1. Replace in-memory store with Oracle Autonomous Database.
2. Add tenant-aware auth and RBAC.
3. Move optimisation logic into `workers/optimisation-worker` using OR-Tools.
4. Add OCI Object Storage for raw payload snapshots.
5. Add OCI Streaming for events and async optimisation jobs.
6. Add OpenAPI generation from shared contracts.

## Current limitations

- In-memory data only
- Greedy heuristic optimisation only
- No authentication yet
- No real OCI integration yet
- No persistence across app restarts
