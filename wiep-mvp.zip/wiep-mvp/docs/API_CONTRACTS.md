# WIEP MVP API Contracts

Base path: `/api/v1` in production. This scaffold currently exposes routes under `/api/*` inside the Next.js app for fast MVP validation.

## Implemented routes

- `POST /api/events`
- `POST /api/forecast`
- `POST /api/labour-requirements`
- `POST /api/optimisation/workforce-mix`
- `POST /api/optimisation/roster`
- `GET /api/recommendations`

## Not yet implemented in scaffold

- dataset file validation
- roster publishing
- scenario simulation
- intraday reallocation
- 3PL margin optimisation
- persistent Oracle database integration
- OCI Streaming integration

These should be added after the thin end-to-end planning loop is validated with customer data.
