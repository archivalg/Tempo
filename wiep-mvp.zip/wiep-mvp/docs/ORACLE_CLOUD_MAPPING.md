# Oracle Cloud Mapping

## MVP deployment target

- Next.js web app: Oracle Kubernetes Engine or OCI Container Instances
- TypeScript API routes/services: initially inside Next.js, later split into Node services on OKE
- Python solver worker: OKE job/pod
- Database: Oracle Autonomous Database
- Raw files and solver snapshots: OCI Object Storage
- Event bus: OCI Streaming
- Secrets: OCI Vault
- Logs/metrics: OCI Logging and Monitoring

## Production split

After MVP validation, split the API routes into services:

- ingestion-api
- workforce-api
- roster-api
- performance-api
- optimisation-orchestrator
- recommendation-api
- reporting-api

Keep Python solver workers separate and called by the optimisation-orchestrator.
