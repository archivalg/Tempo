async function getRecs() {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000';
  try { const r = await fetch(`${base}/api/recommendations`, { cache: 'no-store' }); return (await r.json()).data.recommendations ?? []; } catch { return []; }
}
export default async function Dashboard() {
  const recs = await getRecs();
  return <div className="grid"><h1>Operations Dashboard</h1><div className="grid" style={{gridTemplateColumns:'repeat(4, 1fr)'}}><div className="card"><b>Headcount</b><h2>142</h2></div><div className="card"><b>Projected Cost</b><h2>$29.3k</h2></div><div className="card"><b>Service Level</b><h2>98.5%</h2></div><div className="card"><b>Open Recommendations</b><h2>{recs.length}</h2></div></div><div className="card"><h2>Latest Recommendations</h2>{recs.length ? recs.map((r:any)=><p key={r.recommendationId}><span className="badge">{r.priority}</span> <b>{r.title}</b><br />{r.message}</p>) : <p>No recommendations yet. Run the planning workflow.</p>}</div></div>
}
