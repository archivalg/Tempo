import { NextResponse } from 'next/server';
import { ok } from '@wiep/contracts';
import db from '@/lib/store';
export async function GET() { return NextResponse.json(ok('REQ-REC-LIST', { recommendations: Array.from(db.recommendations.values()) })); }
