import { NextResponse } from 'next/server';
import { LabourRequirementsRequest, fail, ok } from '@wiep/contracts';
import db from '@/lib/store';
import { id } from '@/lib/ids';

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = LabourRequirementsRequest.safeParse(body);
  if (!parsed.success) return NextResponse.json(fail(body?.requestId ?? 'unknown', 'VALIDATION_ERROR', parsed.error.message), { status: 400 });
  const forecast = db.forecasts.get(parsed.data.forecastId);
  if (!forecast) return NextResponse.json(fail(parsed.data.requestId, 'FORECAST_NOT_FOUND', 'Forecast ID was not found'), { status: 404 });
  const labourRequirementId = id('LR');
  const requirements = forecast.forecastBuckets.flatMap((b: any) => parsed.data.labourStandards.filter((s: any) => s.warehouseId === b.warehouseId && s.activityId === b.activityId).map((s: any) => {
    const requiredHours = b.predictedUnits / s.standardUnitsPerHour;
    return { warehouseId: b.warehouseId, activityId: b.activityId, roleId: s.roleId, zoneId: s.zoneId, periodStart: b.periodStart, periodEnd: b.periodEnd, requiredUnits: b.predictedUnits, requiredHours: Number(requiredHours.toFixed(2)), requiredHeadcount: Math.ceil(requiredHours), requiredSkills: s.requiredSkills };
  }));
  const data = { labourRequirementId, requirements };
  db.labourRequirements.set(labourRequirementId, data);
  return NextResponse.json(ok(parsed.data.requestId, data));
}
