import { NextResponse } from 'next/server';
import { EventsRequest, fail, ok } from '@wiep/contracts';
import db from '@/lib/store';
import { id } from '@/lib/ids';

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = EventsRequest.safeParse(body);
  if (!parsed.success) return NextResponse.json(fail(body?.requestId ?? 'unknown', 'VALIDATION_ERROR', parsed.error.message), { status: 400 });
  const seen = new Set(db.events.map((e: any) => e.externalEventId));
  let accepted = 0, duplicate = 0;
  for (const event of parsed.data.events) {
    if (seen.has(event.externalEventId)) { duplicate++; continue; }
    db.events.push({ ...event, sourceSystem: parsed.data.sourceSystem, internalEventId: id('EVT'), ingestedAt: new Date().toISOString() });
    accepted++;
  }
  return NextResponse.json(ok(parsed.data.requestId, { accepted, rejected: 0, duplicate, eventBatchId: id('EVTB') }));
}
