import { NextResponse } from 'next/server';
import { RosterRequest, fail, ok } from '@wiep/contracts';
import db from '@/lib/store';
import { id } from '@/lib/ids';

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = RosterRequest.safeParse(body);
  if (!parsed.success) return NextResponse.json(fail(body?.requestId ?? 'unknown', 'VALIDATION_ERROR', parsed.error.message), { status: 400 });
  const assignments: any[] = [];
  const used = new Set<string>();
  for (const reqt of parsed.data.requirements) {
    const eligible = parsed.data.workers.filter((w: any) => w.availability?.some((a: any) => a.date === reqt.date && a.shiftTemplateId === reqt.shiftTemplateId && a.available) && reqt.requiredSkills.every((s: string) => w.skills?.includes(s)) && !used.has(`${w.workerId}:${reqt.date}:${reqt.shiftTemplateId}`)).sort((a: any,b: any) => ((b.performance?.[0]?.unitsPerHour ?? 0) - (a.performance?.[0]?.unitsPerHour ?? 0)));
    for (const w of eligible.slice(0, reqt.requiredHeadcount)) {
      used.add(`${w.workerId}:${reqt.date}:${reqt.shiftTemplateId}`);
      const tpl = parsed.data.shiftTemplates.find((s: any) => s.shiftTemplateId === reqt.shiftTemplateId);
      assignments.push({ assignmentId: id('ASSIGN'), date: reqt.date, shiftTemplateId: reqt.shiftTemplateId, workerId: w.workerId, warehouseId: reqt.warehouseId, roleId: reqt.roleId, zoneId: reqt.zoneId, startTime: `${reqt.date}T${tpl?.startTime ?? '06:00'}:00Z`, endTime: `${reqt.date}T${tpl?.endTime ?? '14:00'}:00Z`, overtimeHours: 0, assignmentReason: 'Eligible, available and ranked by productivity' });
    }
  }
  const unfilledRequirements = parsed.data.requirements.map((r: any) => ({ ...r, assignedHeadcount: assignments.filter(a => a.date===r.date && a.shiftTemplateId===r.shiftTemplateId && a.roleId===r.roleId && a.zoneId===r.zoneId).length })).filter((r: any) => r.assignedHeadcount < r.requiredHeadcount);
  const rosterOptimisationId = id('ROS'); const rosterVersionId = id('ROSTER-V-DRAFT');
  const data = { rosterOptimisationId, solverStatus: unfilledRequirements.length ? 'MVP_HEURISTIC_PARTIAL' : 'MVP_HEURISTIC_FEASIBLE', objectiveValue: assignments.length, selectedSolution: { solutionType: 'BALANCED', rosterVersionId, assignments, unfilledRequirements, summary: { projectedCost: assignments.length * 276, projectedUnits: assignments.length * 850, projectedServiceLevel: unfilledRequirements.length ? 0.9 : 0.985, fairnessScore: 0.8 } }, explanation: { topDrivers: ['Required skills', 'Availability', 'Productivity ranking'], bindingConstraints: unfilledRequirements.length ? ['QUALIFIED_WORKER_AVAILABILITY'] : [] } };
  db.rosters.set(rosterVersionId, data);
  const recId = id('REC'); db.recommendations.set(recId, { recommendationId: recId, type: 'ROSTER', priority: unfilledRequirements.length ? 'HIGH' : 'MEDIUM', title: unfilledRequirements.length ? 'Roster has unfilled requirements' : 'Roster ready for review', message: unfilledRequirements.length ? 'Request labour hire or relax skill constraints.' : 'Publish the generated AI-assisted roster after supervisor review.', linkedEntities: { rosterOptimisationId, rosterVersionId } });
  return NextResponse.json(ok(parsed.data.requestId, data, unfilledRequirements.length ? [{ code:'PARTIAL_ROSTER', message:'Some requirements were not filled by the MVP heuristic.' }] : []));
}
