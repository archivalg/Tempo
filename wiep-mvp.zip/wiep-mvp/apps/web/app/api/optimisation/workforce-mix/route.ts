import { NextResponse } from 'next/server';
import { WorkforceMixRequest, fail, ok } from '@wiep/contracts';
import db from '@/lib/store';
import { id } from '@/lib/ids';

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = WorkforceMixRequest.safeParse(body);
  if (!parsed.success) return NextResponse.json(fail(body?.requestId ?? 'unknown', 'VALIDATION_ERROR', parsed.error.message), { status: 400 });
  const lr = db.labourRequirements.get(parsed.data.labourRequirementId);
  if (!lr) return NextResponse.json(fail(parsed.data.requestId, 'LABOUR_REQUIREMENT_NOT_FOUND', 'Labour requirement ID was not found'), { status: 404 });
  const mixOptimisationId = id('MIX');
  const assignments: any[] = [];
  let projectedCost = 0, projectedUnits = 0;
  for (const reqt of lr.requirements) {
    let remainingUnits = reqt.requiredUnits;
    const sources = parsed.data.labourSources.map((s: any) => ({ ...s, score: (s.performance?.unitsPerHour ?? 1) / Math.max(s.cost?.hourlyRate ?? 1, 1) })).sort((a: any,b: any) => b.score-a.score);
    for (const source of sources) {
      const avail = source.availableHeadcount?.find((a: any) => a.warehouseId === reqt.warehouseId && a.roleId === reqt.roleId && a.zoneId === reqt.zoneId)?.headcount ?? 0;
      const unitsPerWorker = source.performance?.unitsPerHour ?? 80;
      const needed = Math.ceil(Math.max(remainingUnits,0) / unitsPerWorker);
      const headcount = Math.min(avail, needed);
      if (headcount <= 0) continue;
      const units = headcount * unitsPerWorker;
      const cost = headcount * (source.cost?.hourlyRate ?? 35);
      assignments.push({ warehouseId: reqt.warehouseId, periodStart: reqt.periodStart, periodEnd: reqt.periodEnd, roleId: reqt.roleId, zoneId: reqt.zoneId, labourSourceId: source.labourSourceId, headcount, overtimeHours: 0 });
      remainingUnits -= units; projectedUnits += units; projectedCost += cost;
      if (remainingUnits <= 0) break;
    }
  }
  const data = { mixOptimisationId, solverStatus: 'MVP_HEURISTIC_FEASIBLE', objectiveValue: Number(projectedCost.toFixed(2)), selectedSolution: { solutionType: 'BALANCED', assignments, summary: { projectedCost: Number(projectedCost.toFixed(2)), projectedUnits, projectedServiceLevel: projectedUnits >= lr.requirements.reduce((s: number,r: any)=>s+r.requiredUnits,0) ? 0.99 : 0.9 } }, alternatives: [], explanation: { topDrivers: ['Best productivity per dollar selected first', 'Availability constraints applied', 'MVP uses greedy heuristic placeholder'], bindingConstraints: ['AVAILABILITY'] } };
  db.mixes.set(mixOptimisationId, data);
  const recId = id('REC');
  db.recommendations.set(recId, { recommendationId: recId, type: 'WORKFORCE_MIX', priority: 'HIGH', title: 'Use balanced workforce mix', message: `Projected cost ${data.selectedSolution.summary.projectedCost} with service level ${data.selectedSolution.summary.projectedServiceLevel}.`, linkedEntities: { mixOptimisationId } });
  return NextResponse.json(ok(parsed.data.requestId, data));
}
