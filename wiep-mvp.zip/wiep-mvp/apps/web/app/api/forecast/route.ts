import { NextResponse } from 'next/server';
import { ForecastRequest, fail, ok } from '@wiep/contracts';
import db from '@/lib/store';
import { id } from '@/lib/ids';

function* buckets(start: string, end: string, minutes: number) {
  let t = new Date(start).getTime(); const stop = new Date(end).getTime(); const step = minutes * 60000;
  while (t < stop) { yield [new Date(t).toISOString(), new Date(Math.min(t + step, stop)).toISOString()] as const; t += step; }
}

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = ForecastRequest.safeParse(body);
  if (!parsed.success) return NextResponse.json(fail(body?.requestId ?? 'unknown', 'VALIDATION_ERROR', parsed.error.message), { status: 400 });
  const r = parsed.data;
  const forecastId = id('FC');
  const forecastBuckets: any[] = [];
  for (const wh of r.scope.warehouseIds) for (const activity of r.scope.activityIds) for (const [periodStart, periodEnd] of buckets(r.forecastHorizon.start, r.forecastHorizon.end, r.forecastHorizon.bucketMinutes)) {
    const history = db.events.filter((e: any) => e.warehouseId === wh && e.activityId === activity);
    const avg = history.length ? history.reduce((s: number, e: any) => s + Number(e.quantity ?? 0), 0) / history.length : activity === 'PICK' ? 900 : activity === 'PACK' ? 500 : 300;
    const predictedUnits = Math.round(avg * (new Date(periodStart).getUTCHours() >= 6 && new Date(periodStart).getUTCHours() <= 16 ? 1 : 0.55));
    forecastBuckets.push({ warehouseId: wh, activityId: activity, customerId: r.scope.customerIds?.[0] ?? 'ALL', periodStart, periodEnd, predictedUnits, unitOfMeasure: 'units', confidenceIntervals: [{ confidence: 0.8, lower: Math.round(predictedUnits*0.9), upper: Math.round(predictedUnits*1.1) }, { confidence: 0.95, lower: Math.round(predictedUnits*0.8), upper: Math.round(predictedUnits*1.2) }] });
  }
  const data = { forecastId, modelUsed: 'BASELINE_AVERAGE_MVP', forecastBuckets };
  db.forecasts.set(forecastId, data);
  return NextResponse.json(ok(r.requestId, data));
}
