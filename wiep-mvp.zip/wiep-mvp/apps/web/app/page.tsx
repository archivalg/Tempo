import Link from 'next/link';
export default function Home() {
  return <div className="card"><h1>Workforce Intelligence & Execution Platform</h1><p>MVP scaffold for warehouse labour forecasting, optimisation, rostering and recommendations.</p><Link className="btn" href="/dashboard">Open MVP</Link></div>;
}
