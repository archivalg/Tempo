import './globals.css';
import Link from 'next/link';

export const metadata = { title: 'WIEP MVP', description: 'Warehouse Workforce Intelligence MVP' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <nav style={{display:'flex', gap:20, alignItems:'center', padding:'16px 24px', background:'#fff', borderBottom:'1px solid #e5e7eb'}}>
          <strong>WIEP MVP</strong>
          <Link href="/dashboard">Dashboard</Link>
          <Link href="/planning">Planning</Link>
          <Link href="/roster">Roster</Link>
          <Link href="/recommendations">Recommendations</Link>
        </nav>
        <main style={{padding:24, maxWidth:1200, margin:'0 auto'}}>{children}</main>
      </body>
    </html>
  );
}
