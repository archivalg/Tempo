/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ["@wiep/contracts"]
};
export default nextConfig;
