type Row = Record<string, any>;
const db = (globalThis as any).__wiepDb ?? {
  events: [] as Row[],
  forecasts: new Map<string, Row>(),
  labourRequirements: new Map<string, Row>(),
  mixes: new Map<string, Row>(),
  rosters: new Map<string, Row>(),
  recommendations: new Map<string, Row>()
};
(globalThis as any).__wiepDb = db;
export default db;
