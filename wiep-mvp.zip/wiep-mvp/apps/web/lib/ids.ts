export function id(prefix: string) { return `${prefix}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`; }
export function hoursBetween(start: string, end: string) { return (new Date(end).getTime() - new Date(start).getTime()) / 36e5; }
