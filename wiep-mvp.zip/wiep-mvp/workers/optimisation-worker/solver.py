"""MVP optimisation worker placeholder.

Replace greedy heuristics with OR-Tools CP-SAT/MILP models when moving beyond MVP.
This worker is intentionally isolated from the Next.js app so production can run it as an OKE job/pod.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List


@dataclass
class LabourSource:
    id: str
    hourly_rate: float
    units_per_hour: float
    available_headcount: int


def solve_workforce_mix(required_units: float, sources: List[LabourSource]) -> Dict[str, Any]:
    """Greedy MVP heuristic: choose best units-per-dollar first."""
    remaining = required_units
    assignments = []
    cost = 0.0
    for source in sorted(sources, key=lambda s: s.units_per_hour / max(s.hourly_rate, 1), reverse=True):
        if remaining <= 0:
            break
        needed = int((remaining + source.units_per_hour - 1) // source.units_per_hour)
        headcount = min(source.available_headcount, needed)
        if headcount <= 0:
            continue
        produced = headcount * source.units_per_hour
        assignments.append({"labourSourceId": source.id, "headcount": headcount, "projectedUnits": produced})
        cost += headcount * source.hourly_rate
        remaining -= produced
    return {
        "solverStatus": "MVP_HEURISTIC_FEASIBLE" if remaining <= 0 else "MVP_HEURISTIC_PARTIAL",
        "projectedCost": round(cost, 2),
        "unmetUnits": max(0, remaining),
        "assignments": assignments,
    }


if __name__ == "__main__":
    print(solve_workforce_mix(920, [LabourSource("internal", 34.5, 115, 7), LabourSource("hire", 39, 95, 10)]))
