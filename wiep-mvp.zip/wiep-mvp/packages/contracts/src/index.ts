import { z } from 'zod';

export const ApiWarning = z.object({ code: z.string(), message: z.string() });
export function ok<T>(requestId: string, data: T, warnings: z.infer<typeof ApiWarning>[] = []) {
  return { requestId, status: 'success' as const, data, errors: [], warnings };
}
export function fail(requestId: string, code: string, message: string, data: unknown = null) {
  return { requestId, status: 'failed' as const, data, errors: [{ code, message }], warnings: [] };
}
export const PlanningHorizon = z.object({ start: z.string().datetime(), end: z.string().datetime(), bucketMinutes: z.number().int().positive() });
export const EventRecord = z.object({ externalEventId: z.string(), eventType: z.string(), occurredAt: z.string().datetime(), workerId: z.string().optional(), warehouseId: z.string(), zoneId: z.string().optional(), functionalAreaId: z.string().optional(), roleId: z.string().optional(), activityId: z.string(), orderId: z.string().optional(), customerId: z.string().optional(), quantity: z.number().nonnegative(), unitOfMeasure: z.string(), durationSeconds: z.number().int().nonnegative().optional(), deviceId: z.string().optional(), metadata: z.record(z.unknown()).optional() });
export const EventsRequest = z.object({ requestId: z.string(), sourceSystem: z.string(), events: z.array(EventRecord).min(1) });
export const ForecastRequest = z.object({ requestId: z.string(), datasetId: z.string().optional(), forecastHorizon: PlanningHorizon, scope: z.object({ warehouseIds: z.array(z.string()), activityIds: z.array(z.string()), customerIds: z.array(z.string()).optional() }), options: z.object({ modelType: z.string().default('AUTO'), includeConfidenceIntervals: z.boolean().default(true), confidenceLevels: z.array(z.number()).default([0.8, 0.95]) }).optional() });
export const LabourStandard = z.object({ warehouseId: z.string(), activityId: z.string(), roleId: z.string(), zoneId: z.string(), standardUnitsPerHour: z.number().positive(), requiredSkills: z.array(z.string()).default([]) });
export const LabourRequirementsRequest = z.object({ requestId: z.string(), forecastId: z.string(), labourStandards: z.array(LabourStandard), options: z.object({ roundingMode: z.enum(['CEILING','FLOOR','NEAREST']).default('CEILING'), minimumHeadcountPerRoleZone: z.boolean().default(true) }).optional() });
export const WorkforceMixRequest = z.object({ requestId: z.string(), labourRequirementId: z.string(), planningHorizon: PlanningHorizon, labourSources: z.array(z.any()), constraints: z.record(z.unknown()).optional(), objective: z.record(z.unknown()).optional(), options: z.record(z.unknown()).optional() });
export const RosterRequest = z.object({ requestId: z.string(), labourRequirementId: z.string(), mixOptimisationId: z.string(), planningHorizon: PlanningHorizon, shiftTemplates: z.array(z.any()), workers: z.array(z.any()), requirements: z.array(z.any()), constraints: z.record(z.unknown()).optional(), objective: z.record(z.unknown()).optional(), options: z.record(z.unknown()).optional() });
